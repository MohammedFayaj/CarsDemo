package net.riotopsys.demo.pizzame.inject;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.util.Log;

import net.riotopsys.demo.pizzame.network.YahooQueryLanguage;
import net.riotopsys.demo.pizzame.network.model.QueryResult;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Observable;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Func1;
import rx.functions.Func2;
import rx.schedulers.Schedulers;
import rx.subjects.BehaviorSubject;

/**
 * Created by adam on 7/31/16.
 */
@Module
public class MainModule {

    private static final String QUERY_FORMAT = "select * from local.search where zip='%s' and query='pizza'";


    private Context context;

    public MainModule(Context context) {
        this.context = context;
    }

    @Provides
    public Context provideContext() {
        return context;
    }

    @Provides
    public Geocoder provideGeocoder(Context ctx) {
        return new Geocoder(ctx, Locale.getDefault());
    }

    @Provides
    public Retrofit provideRetrofitBuilder(OkHttpClient client) {
        return new Retrofit.Builder()
                .baseUrl("https://query.yahooapis.com")
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }


    @Singleton
    @Provides
    public OkHttpClient getClient() {

        return new OkHttpClient.Builder()
                .addNetworkInterceptor(new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
                    @Override
                    public void log(String message) {
                        Log.i("LOG", message);
                    }
                }).setLevel(HttpLoggingInterceptor.Level.BODY))
                .build();
    }

    @Provides
    public YahooQueryLanguage provideYQL(Retrofit retrofit) {
        return retrofit.create(YahooQueryLanguage.class);
    }

    @Singleton
    @Provides
    public BehaviorSubject<Location> provideLocationSubject() {
        return BehaviorSubject.create();
    }

    @Singleton
    @Provides
    public Observable<Location> provideLocationSource(BehaviorSubject<Location> locationSubject) {
        return locationSubject.share();
    }

    @Singleton
    @Provides
    public Observable<Response<QueryResult>> providePizzaSource(final Observable<Location> locationSource, final Geocoder geocoder, final YahooQueryLanguage yql) {
        return locationSource.map(new Func1<Location, Address>() {
            @Override
            public Address call(Location location) {
                try {
                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    return (addresses.size() > 0) ? addresses.get(0) : null;
                } catch (IOException e) {
                    return null;
                }
            }
        }).flatMap(new Func1<Address, Observable<Response<QueryResult>>>() {
            @Override
            public Observable<Response<QueryResult>> call(Address address) {
                if (address == null) {

                    Response<QueryResult> response = Response.error(404, ResponseBody.create(null, "No address found"));

                    return Observable.just(response);
                }
                return yql.getPlaces(String.format(QUERY_FORMAT, address.getPostalCode()), "json").subscribeOn(Schedulers.io());
            }
        }).zipWith(locationSource, new Func2<Response<QueryResult>, Location, Response<QueryResult>>() {
            @Override
            public Response<QueryResult> call(Response<QueryResult> queryResult, Location location) {

                if (!queryResult.isSuccessful()) {
                    return queryResult;
                }

                for (QueryResult.Result result : queryResult.body().query.results.result) {
                    Location resultLoc = new Location("");
                    resultLoc.setLatitude(result.latitude);
                    resultLoc.setLongitude(result.longitude);

                    result.calc = new QueryResult.Calculated();

                    result.calc.distance = location.distanceTo(resultLoc);
                }

                return queryResult;
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .cache();
    }


}
