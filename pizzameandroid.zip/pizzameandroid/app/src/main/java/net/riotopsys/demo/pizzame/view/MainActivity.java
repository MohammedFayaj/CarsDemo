package net.riotopsys.demo.pizzame.view;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;

import net.riotopsys.demo.pizzame.R;
import net.riotopsys.demo.pizzame.service.LocationService;

public class MainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_FINE_LOCATION = 0xC;

    private LocationManager locationManager;

    private PendingIntent pendingLocationIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.content, new ListResultFragment())
                .commit();

        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_FINE_LOCATION);

        } else {
            startPolling();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopPolling();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_FINE_LOCATION: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startPolling();
                } else {
                    finish();
                }
                return;
            }
            default:
        }
    }

    @SuppressWarnings({"MissingPermission"})
    private void startPolling() {
        pendingLocationIntent = PendingIntent.getService(this, 0, new Intent(this, LocationService.class), PendingIntent.FLAG_UPDATE_CURRENT);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0l, 0f, pendingLocationIntent);
        locationManager.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 0l, 0f, pendingLocationIntent);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0l, 0f, pendingLocationIntent);

    }

    @SuppressWarnings({"MissingPermission"})
    private void stopPolling() {
        if (pendingLocationIntent != null) {
            locationManager.removeUpdates(pendingLocationIntent);
            pendingLocationIntent = null;
        }
    }

}
