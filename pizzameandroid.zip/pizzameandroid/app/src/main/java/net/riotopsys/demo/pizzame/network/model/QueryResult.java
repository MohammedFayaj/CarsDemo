package net.riotopsys.demo.pizzame.network.model;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.net.URL;
import java.util.List;

/**
 * Created by adam on 7/31/16.
 */
public class QueryResult {

    @SerializedName("query")
    public Query query;

    public static class Query {
        @SerializedName("count")
        public int count;

        @SerializedName("results")
        public ResultsObject results;
    }

    public static class ResultsObject {
        @SerializedName("Result")
        public List<Result> result;
    }

    public static class Result implements Serializable {
        @SerializedName("Title")
        public String title;

        @SerializedName("Address")
        public String address;

        @SerializedName("City")
        public String city;


        @SerializedName("State")
        public String state;

        @SerializedName("Phone")
        public String phone;


        @SerializedName("Latitude")
        public Float latitude;

        @SerializedName("Longitude")
        public Float longitude;

        @SerializedName("BusinessUrl")
        public URL businessUrl;

        public Calculated calc;
    }

    public static class Calculated implements Serializable {
        public float distance;
    }
}