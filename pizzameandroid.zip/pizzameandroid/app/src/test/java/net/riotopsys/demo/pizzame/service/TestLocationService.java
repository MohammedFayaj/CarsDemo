package net.riotopsys.demo.pizzame.service;

import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import rx.Observer;
import rx.Subscription;
import rx.subjects.BehaviorSubject;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by adam.fitzgerald on 2/8/17.
 */

public class TestLocationService {


    private List<Location> reportedLocations = new ArrayList<>();
    private Subscription subscription = null;
    private BehaviorSubject<Location> subject;

    private Observer<? super Location> observer = new Observer<Location>() {
        @Override
        public void onCompleted() {

        }

        @Override
        public void onError(Throwable e) {

        }

        @Override
        public void onNext(Location location) {
            reportedLocations.add(location);
        }
    };


    @Before
    public void setup() {
        subject = BehaviorSubject.create();
        subscription = subject.subscribe(observer);
    }

    @After
    public void reset() {
        subscription.unsubscribe();
        reportedLocations.clear();
    }


    @Test
    public void happyPath() {


        LocationService dut = new LocationService();

        dut.locationSubject = subject;

        Intent intent = mock(Intent.class);
        Location location = mock(Location.class);
        when(location.getAccuracy()).thenReturn(20f);

        when(intent.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED)).thenReturn(location);

        dut.onHandleIntent(intent);

        assertEquals(1, reportedLocations.size());
        assertEquals(location, reportedLocations.get(0));


    }

    @Test
    public void blitzOfLocationsOnlySendsOneUpdateInAShortPeriod() {


        LocationService dut = new LocationService();

        dut.locationSubject = subject;

        Long now = System.currentTimeMillis();


        Intent intentA = createMockIntent(now + 2, 20f);

        dut.onHandleIntent(intentA);
        dut.onHandleIntent(createMockIntent(now + 2, 20f));
        dut.onHandleIntent(createMockIntent(now + 4, 20f));
        dut.onHandleIntent(createMockIntent(now + 6, 20f));

        assertEquals(1, reportedLocations.size());
        assertEquals(intentA.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED), reportedLocations.get(0));


    }

    private Intent createMockIntent(long time, float accuracy) {
        Intent intent = mock(Intent.class);
        Location location = mock(Location.class);
        when(location.getAccuracy()).thenReturn(accuracy);
        when(location.hasAccuracy()).thenReturn(true);
        when(location.getTime()).thenReturn(time);

        when(intent.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED)).thenReturn(location);

        return intent;
    }

    @Test
    public void blitzOfLocationsOnlySendsMultipuleUpdatesInALongPeriod() {

        LocationService dut = new LocationService();

        dut.locationSubject = subject;

        Long now = System.currentTimeMillis();


        Intent intentA = createMockIntent(now, 20f);
        dut.onHandleIntent(intentA);
        dut.onHandleIntent(createMockIntent(now + 2, 20f));
        dut.onHandleIntent(createMockIntent(now + 2, 20f));
        dut.onHandleIntent(createMockIntent(now + 2, 20f));

        Intent intentB = createMockIntent(now + 6000, 20f);
        dut.onHandleIntent(intentB);
        dut.onHandleIntent(createMockIntent(now + 6002, 20f));
        dut.onHandleIntent(createMockIntent(now + 6003, 20f));
        dut.onHandleIntent(createMockIntent(now + 6004, 20f));

        assertEquals(2, reportedLocations.size());
        assertEquals(intentA.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED), reportedLocations.get(0));
        assertEquals(intentB.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED), reportedLocations.get(1));
    }

    @Test
    public void blitzOfLocationsOnlySendsMultipuleUpdatesInALongPeriodUnlessAccIsBad() {

        LocationService dut = new LocationService();

        dut.locationSubject = subject;

        Long now = System.currentTimeMillis();


        Intent intentA = createMockIntent(now, 20f);
        dut.onHandleIntent(intentA);
        dut.onHandleIntent(createMockIntent(now + 2, 20f));
        dut.onHandleIntent(createMockIntent(now + 2, 20f));
        dut.onHandleIntent(createMockIntent(now + 2, 20f));

        Intent intentB = createMockIntent(now + 6000, 1000f);
        dut.onHandleIntent(intentB);
        dut.onHandleIntent(createMockIntent(now + 6002, 1000f));
        dut.onHandleIntent(createMockIntent(now + 6003, 1000f));
        dut.onHandleIntent(createMockIntent(now + 6004, 1000f));

        assertEquals(1, reportedLocations.size());
        assertEquals(intentA.getParcelableExtra(LocationManager.KEY_LOCATION_CHANGED), reportedLocations.get(0));
    }

}
